define(["./block.js"], function (_block) {
  "use strict";

  // @flow
  document.title = (0, _block.$internationalizeDefault)('how_to_use_smart_settings');
});