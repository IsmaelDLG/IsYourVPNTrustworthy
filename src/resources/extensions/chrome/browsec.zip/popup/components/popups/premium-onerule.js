define(["exports", "../head.js"], function (_exports, _head) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.$premiumOneruleTemplateDefault = _render;
  _exports.$premiumOneruleTemplate = void 0;

  function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = babelHelpers.getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = babelHelpers.getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return babelHelpers.possibleConstructorReturn(this, result); }; }

  function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

  function _templateObject5_3fc5bdb018f511eb992faba69ef4ab6d() {
    var data = babelHelpers.taggedTemplateLiteral(["\n    <div class=\"ExtraText\">", "</div>"]);

    _templateObject5_3fc5bdb018f511eb992faba69ef4ab6d = function _templateObject5_3fc5bdb018f511eb992faba69ef4ab6d() {
      return data;
    };

    return data;
  }

  function _templateObject4_3fc5bdb018f511eb992faba69ef4ab6d() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <span class=\"Button_Discount\"><span class=\"In\"><span class=\"In\"><!--\n     --><span class=\"Button_Discount_Minus\">-</span><!--\n     --><span class=\"Button_Discount_Value\">", "</span><!--\n     --><span class=\"Button_Discount_Percent\">%</span><!--\n   --></span></span></span>"]);

    _templateObject4_3fc5bdb018f511eb992faba69ef4ab6d = function _templateObject4_3fc5bdb018f511eb992faba69ef4ab6d() {
      return data;
    };

    return data;
  }

  function _templateObject3_3fc5bdb018f511eb992faba69ef4ab6d() {
    var data = babelHelpers.taggedTemplateLiteral(["\n          ", "\n          <span class=\"Button_Price_Value\">", "", "</span>\n          <span class=\"Button_Price_OldValue\">", "", "</span>"]);

    _templateObject3_3fc5bdb018f511eb992faba69ef4ab6d = function _templateObject3_3fc5bdb018f511eb992faba69ef4ab6d() {
      return data;
    };

    return data;
  }

  function _templateObject2_3fc5bdb018f511eb992faba69ef4ab6d() {
    var data = babelHelpers.taggedTemplateLiteral(["\n        <span class=\"Button_Price\">\n        ", "\n        </span>"]);

    _templateObject2_3fc5bdb018f511eb992faba69ef4ab6d = function _templateObject2_3fc5bdb018f511eb992faba69ef4ab6d() {
      return data;
    };

    return data;
  }

  function _templateObject_3fc5bdb018f511eb992faba69ef4ab6d() {
    var data = babelHelpers.taggedTemplateLiteral(["\n  <style>\n  ", "\n  :host{\n    display: block;\n    position: absolute;\n    z-index: 3;\n    top:0px;right:0px;left:0px;\n    height: 100%;\n    background: #fff;\n  }\n\n  .Head{\n    background: #28344f;\n    color: #fff;\n    text-align: center;\n    font-size: 17px;\n    line-height: 36px;\n    font-weight: 500;\n    position: relative;\n    padding: 9px 10px 9px;\n  }\n\n  .Close{\n    position: absolute;\n    top: 50%;\n    right: 0;\n    margin-top: -16px;\n    width: 10px;\n    padding-top: 10px;\n    border: 11px solid transparent;\n    height: 0;\n    overflow: hidden;\n    background: url( '/images/popup_close_2.svg#grey' ) 0 0 no-repeat;\n    background-size: 100% 100%;\n    cursor: pointer;\n  }\n  .Close:hover{\n    background-image: url( '/images/popup_close_2.svg#white' );\n  }\n  .Close::after{\n    content: '';\n    display: block;\n    position: absolute;\n    width: 1px;\n    height: 1px;\n    top: 0;\n    left: 0;\n    background: url( '/images/popup_close_2.svg#white' ) 0 -5000px no-repeat;\n  }\n\n  .Text{\n    padding: 20px 25px;\n    color: #28344f;\n    line-height: 1.35;\n  }\n  .Title{\n    font-size: 18px;\n    font-weight: 600;\n    padding-bottom: 15px;\n  }\n  .Description{\n    font-size: 16px;\n  }\n  .Description p{\n    padding-bottom: 1em;\n  }\n  .Description ul{\n    list-style: none;\n  }\n  .Description ul > li{\n    position: relative;\n    padding-left: 20px;\n  }\n  .Description ul > li::after{\n    content: '';\n    background: url( '/images/popup-help/check.svg' ) 0 0 no-repeat;\n    background-size: 100% 100%;\n    width: 12px;\n    overflow:hidden;font-size:0;text-indent:-9999px;height:0;\n    padding-top: 9px;\n    position: absolute;\n    top: 50%;\n    margin-top: -5px;\n    left: 0;\n  }\n\n  .Button_Out{\n    /* position: absolute;right:5px;bottom:5px;left:5px; */\n    padding: 0 5px;\n  }\n  .Button{\n    display: table;\n    width: 100%;\n    height: 60px;\n    background: #3d973f;\n    text-align: center;\n    border-radius: 4px;\n    position: relative;\n  }\n  .Button:link,\n  .Button:visited,\n  .Button:hover,\n  .Button:active{\n    color: #fff;\n    text-decoration: none;\n  }\n  .Button *{\n    cursor: pointer;\n  }\n  .Button > .In{\n    display: table-cell;\n    vertical-align: middle;\n  }\n\n  .Button_Name{\n    display: block;\n    font-size: 16px;\n    font-weight: 600;\n  }\n  .Button_Name.uppercase{\n    text-transform: uppercase;\n  }\n\n  .Button_Price{\n    display: block;\n    font-size: 14px;\n  }\n  .Button_Price_Value{\n    font-size: 14px;\n    font-weight: bold;\n  }\n  .Button_Price_OldValue{\n    font-size: 12px;\n    text-decoration: line-through;\n    color: #9aca9f;\n    margin-left: 3px;\n  }\n\n  .Button_Discount{\n    display: block;\n    position: absolute;\n    top: 0;\n    bottom: 0;\n    right: 25px;\n  }\n  .Button_Discount > .In{\n    width: 54px;\n    height: 54px;\n    background: url( '/images/discount.svg' ) 0 0 no-repeat;\n    display: table;\n    position: absolute;\n    right: 0;\n    top: calc(50% - 54px / 2);\n  }\n  .Button_Discount > .In > .In{\n    display: table-cell;\n    vertical-align: middle;\n  }\n  .Button_Discount_Minus{\n    display: inline-block;\n    vertical-align: middle;\n    font-size: 16px;\n    font-weight: bold;\n  }\n  .Button_Discount_Value{\n    display: inline-block;\n    vertical-align: middle;\n    font-size: 23px;\n    font-weight: bold;\n  }\n  .Button_Discount_Percent{\n    display: inline-block;\n    vertical-align: middle;\n    font-size: 12px;\n    font-weight: bold;\n  }\n\n  .ExtraText{\n    color: #808080;\n    font-size: 12px;\n    text-align: center;\n    padding-top: 7px;\n  }\n  </style>\n\n  <div class=\"Head\">\n    ", "\n    <div class=\"Close\" @click=\"", "\"></div>\n  </div>\n  <div class=\"Text\">\n    <div class=\"Title\">", "</div>\n    <div class=\"Description\">\n      <p>", "</p>\n      <p>", "</p>\n      <ul>\n        <li>", "</li>\n        <li>", "</li>\n      </ul>\n    </div>\n  </div>\n  <div class=\"Button_Out\">\n    <a href=\"", "\" class=\"Button\" @click=\"", "\" target=\"_blank\">\n      <span class=\"In\">\n        <span class=\"Button_Name ", "\">\n          ", "\n        </span>\n      ", "\n      </span>\n      ", "\n    </a>\n  </div>\n  ", ""]);

    _templateObject_3fc5bdb018f511eb992faba69ef4ab6d = function _templateObject_3fc5bdb018f511eb992faba69ef4ab6d() {
      return data;
    };

    return data;
  }

  var translations
  /*: { [ string ]: string }*/
  = (0, _head.$createTranslationObjectDefault)({
    'browsecPremium': 'browsec_premium',
    'cancelSubscriptionAtAnyTime': 'cancel_subscription_at_any_time',
    'forOnly': 'for_only',
    'moneyBackGuarantee': '7_days_money_back_guarantee',
    'oneSmartSettingDescription1': 'one_smart_setting_description_1',
    'oneSmartSettingDescription2': 'one_smart_setting_description_2',
    'oneSmartSettingDescriptionList1': 'one_smart_setting_description_list_1',
    'oneSmartSettingDescriptionList2': 'one_smart_setting_description_list_2',
    'youCanHaveOnlyOneSmartSetting': 'you_can_have_only_1_smart_setting'
  });
  /** @method */

  function _render()
  /*: string */
  {
    var _this = this;

    var onlyPricePerMonth
    /*: string*/
    = (0, _head.$internationalizeDefault)('only_X_per_month').replace(/XXX/g, this.currency + this.price);
    return (0, _head.html)(_templateObject_3fc5bdb018f511eb992faba69ef4ab6d(), _head.$globalStyleDefault, translations.browsecPremium, this.close, translations.youCanHaveOnlyOneSmartSetting, translations.oneSmartSettingDescription1, translations.oneSmartSettingDescription2, translations.oneSmartSettingDescriptionList1, translations.oneSmartSettingDescriptionList2, this.premiumLink, this.linkClick, this.trialDays && !this.withPrice ? 'uppercase' : '', this.buttonText, function () {
      if (!_this.withPrice || _this.trialDays) return '';
      return (0, _head.html)(_templateObject2_3fc5bdb018f511eb992faba69ef4ab6d(), function () {
        if (!_this.discount) return onlyPricePerMonth;
        return (0, _head.html)(_templateObject3_3fc5bdb018f511eb992faba69ef4ab6d(), translations.forOnly, _this.currency, _this.price, _this.currency, _this.oldPrice);
      }());
    }(), function () {
      if (!_this.withPrice || !_this.discount) return '';
      return (0, _head.html)(_templateObject4_3fc5bdb018f511eb992faba69ef4ab6d(), _this.discount);
    }(), function () {
      if (!_this.withPrice) return '';
      var translation
      /*: string*/
      = _this.trialDays ? translations.cancelSubscriptionAtAnyTime : translations.moneyBackGuarantee;
      return (0, _head.html)(_templateObject5_3fc5bdb018f511eb992faba69ef4ab6d(), translation);
    }());
  }

  var premiumOneruleTemplate = {
    __proto__: null,
    'default': _render
  };
  _exports.$premiumOneruleTemplate = premiumOneruleTemplate;

  var PopupPremiumOnerule = /*#__PURE__*/function (_connect) {
    babelHelpers.inherits(PopupPremiumOnerule, _connect);

    var _super = _createSuper(PopupPremiumOnerule);

    babelHelpers.createClass(PopupPremiumOnerule, [{
      key: "render",
      value: function render() {
        return _render.call(this);
      }
    }, {
      key: "stateChanged",

      /** @method */
      value: function stateChanged(_ref)
      /*: void*/
      {
        var prices = _ref.prices,
            priceTrial = _ref.priceTrial;

        var _pricesPreView = (0, _head.$pricesPreViewDefault)({
          prices: prices,
          priceTrial: priceTrial
        }),
            currency = _pricesPreView.currency,
            price = _pricesPreView.price,
            oldPrice = _pricesPreView.oldPrice,
            trialDays = _pricesPreView.trialDays;

        this.currency = currency;
        this.price = price;
        this.oldPrice = oldPrice;
        this.trialDays = trialDays;
      } // Lifecycle

    }, {
      key: "buttonText",
      // Properties
      get: function get()
      /*: string*/
      {
        if (!this.withPrice) return (0, _head.$internationalizeDefault)('get_premium_now');

        if (this.trialDays) {
          return (0, _head.$internationalizeDefault)('get_N_days_free_premium_trial').replace(/XXX/g, this.trialDays);
        }

        if (this.discount) {
          return (0, _head.$internationalizeDefault)('get_monthly_premium');
        }

        return (0, _head.$internationalizeDefault)('upgrade_to_premium');
      }
    }, {
      key: "discount",
      get: function get() {
        return !this.oldPrice ? 0 : Math.floor(100 * (this.oldPrice - this.price) / this.oldPrice);
      }
    }, {
      key: "extraText",
      get: function get()
      /*: string*/
      {
        if (!this.withPrice || this.trialDays) return '';

        if (!this.discount) {
          return (0, _head.$internationalizeDefault)('only_X_per_month').replace(/XXX/g, this.currency + this.price);
        }

        return (0, _head.$internationalizeDefault)('for_only') + ' ' + this.currency + this.price;
      }
    }, {
      key: "premiumLink",
      get: function get() {
        var _this3 = this;

        var _window = window,
            browsecLink = _window.browsecLink,
            pageLinks = _window.pageLinks;
        var extraText
        /*: string */
        = this.extraText;
        if (extraText) extraText = '. ' + extraText;

        var storeState = _head.$storeDefault.getState();

        var now
        /*: integer*/
        = Date.now();
        var activePromotionWithTariff
        /*: Promotion | void*/
        = storeState.promotions.find(function (_ref2) {
          var from = _ref2.from,
              till = _ref2.till,
              tariffs = _ref2.tariffs;
          return from <= now && now <= till && tariffs;
        });
        var campaign
        /*: string*/
        = activePromotionWithTariff ? activePromotionWithTariff.id : 'default_campaign';

        var prices
        /*: Price[]*/
        = function () {
          if (!activePromotionWithTariff) return _head.$defaultPricesDefault;
          var tariffs = activePromotionWithTariff.tariffs;

          if (!tariffs) {
            throw new Error('No "tariffs" property in tariff');
          }

          return tariffs.map(function (_ref3) {
            var _ref3$price = _ref3['price'],
                currency = _ref3$price.currency,
                value = _ref3$price.value,
                duration = _ref3.duration;
            return {
              currency: currency,
              duration: duration,
              value: value
            };
          });
        }();

        var plan
        /*: string*/
        = function () {
          var convertedTariffs = prices.map(function (_ref4) {
            var duration = _ref4.duration,
                price = _ref4['value'];
            return {
              duration: duration,
              'pricePerMonth': price / duration
            };
          }).sort(function (_ref5, _ref6) {
            var a = _ref5['pricePerMonth'];
            var b = _ref6['pricePerMonth'];
            return a - b;
          });
          var duration = convertedTariffs[0].duration;

          switch (duration) {
            case 1:
              return 'monthly';

            case 12:
              return 'annual';

            case 24:
              return 'biennial';

            default:
              throw new Error('Incorrect duration');
          }
        }();

        return browsecLink(activePromotionWithTariff && activePromotionWithTariff.clickUrl || pageLinks.premium, function (search) {
          return Object.assign(search, {
            'plan_id': plan,
            'utm_source': 'chromium extension',
            'utm_medium': 'premium_div',
            'utm_campaign': campaign,
            'utm_term': _this3.buttonText + extraText
          });
        });
      }
    }], [{
      key: "properties",
      get: function get() {
        return {
          'buttonText': {
            'type': String
          },
          'currency': {
            'type': String
          },
          'discount': {
            'type': Number
          },
          'oldPrice': {
            'type': Number
          },
          'premiumLink': {
            'type': String
          },
          'price': {
            'type': Number
          },
          'trialDays': {
            'type': Number
          }
        };
      }
    }]);

    function PopupPremiumOnerule() {
      var _this2;

      babelHelpers.classCallCheck(this, PopupPremiumOnerule);
      _this2 = _super.call(this);
      _this2.withPrice = Math.floor(Math.random() * 2) === 1; // Random true/false

      return _this2;
    }
    /** @method */


    babelHelpers.createClass(PopupPremiumOnerule, [{
      key: "connectedCallback",
      value: function connectedCallback() {
        babelHelpers.get(babelHelpers.getPrototypeOf(PopupPremiumOnerule.prototype), "connectedCallback", this).call(this);
        if (this.firstConnect) return;
        this.firstConnect = true;
        var extraText
        /*: string*/
        = this.extraText;
        if (extraText) extraText = '. ' + extraText;
        (0, _head.$gaDefault)({
          'action': 'show_premium_div',
          'category': 'extension',
          'label': 'premium_div_' + this.buttonText + extraText
        });
      } // Methods

      /** @method */

    }, {
      key: "linkClick",
      value: function () {
        var _linkClick = babelHelpers.asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  (0, _head.$gaDefault)('premium', 'click'); // For FF and early Chrome

                  _context.next = 3;
                  return new Promise(function (resolve) {
                    setTimeout(resolve, 50);
                  });

                case 3:
                  if (window && window.close) window.close();

                case 4:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee);
        }));

        function linkClick() {
          return _linkClick.apply(this, arguments);
        }

        return linkClick;
      }()
      /** @method */

    }, {
      key: "close",
      value: function () {
        var _close = babelHelpers.asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
          var _this4 = this;

          var ffVersion, duration, start, end, animation;
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  _context2.next = 2;
                  return _head.$firefoxVersionDefault;

                case 2:
                  ffVersion = _context2.sent;
                  duration = 800;

                  if (!(typeof ffVersion === 'number' && ffVersion <= 62)) {
                    _context2.next = 11;
                    break;
                  }

                  start = 0;
                  end = -100;
                  _context2.next = 9;
                  return (0, _head.$animateDefault)({
                    duration: duration,
                    'action': function action(percent) {
                      var value
                      /*: number */
                      = percent * (end - start) + start;
                      _this4.style.cssText = "top:".concat(value, "%;");
                    }
                  });

                case 9:
                  _context2.next = 14;
                  break;

                case 11:
                  animation = this.animate([{
                    'top': 0
                  }, {
                    'top': '-100%'
                  }], {
                    duration: duration,
                    'easing': 'linear'
                  });
                  _context2.next = 14;
                  return new Promise(function (resolve) {
                    animation.onfinish = resolve;
                  });

                case 14:
                  this.remove();

                case 15:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function close() {
          return _close.apply(this, arguments);
        }

        return close;
      }()
    }]);
    return PopupPremiumOnerule;
  }((0, _head.connect)(_head.$storeDefault)(_head.LitElement));

  ;
  customElements.define('popup-premium-onerule', PopupPremiumOnerule);
});