define(["./block.js"], function (_block) {
  "use strict";

  // @flow
  babelHelpers.asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
    var storeState, parentElement;
    return regeneratorRuntime.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return (0, _block.$sendMessageDefault)({
              'type': 'store.getState'
            });

          case 2:
            storeState
            /*: StoreState*/
            = _context.sent;

            _block.$storeDefault.activate(storeState);

            parentElement = document.querySelector('div.Main > div.In');

            if (parentElement) {
              _context.next = 7;
              break;
            }

            return _context.abrupt("return");

          case 7:
            parentElement.append(document.createElement('main-block'));

          case 8:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }))(); // Separate page

  document.title = (0, _block.$internationalizeDefault)('you_just_installed_browsec');
});