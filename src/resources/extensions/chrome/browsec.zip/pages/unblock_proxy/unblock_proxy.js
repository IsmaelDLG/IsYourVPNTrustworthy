define(["./block.js"], function (_block) {
  "use strict";

  // @flow
  document.title = (0, _block.$internationalizeDefault)('your_proxy_settings_are_blocked');
});