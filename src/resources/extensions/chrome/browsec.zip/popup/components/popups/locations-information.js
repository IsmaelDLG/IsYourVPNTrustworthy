define(["../head.js"], function (_head) {
  "use strict";

  function _templateObject_3fb9d6d018f511eb992faba69ef4ab6d() {
    var data = babelHelpers.taggedTemplateLiteral(["\n    <style>\n    ", "\n    :host{\n      display: block;\n      font-size: 14px;\n      line-height: 1.3;\n      color: #28344f;\n      position: absolute;\n      top: 0;\n      left: 0;\n      width: 100%;\n      height: 100%;\n      z-index: 2;\n    }\n    :host > .Overlay{\n      position: absolute;\n      top:0px;right:0px;bottom:0px;left:0px;\n      overflow: hidden;\n      text-indent: -9999px;\n      font-size: 0;\n      background: rgba(255, 255, 255, 0.5);\n    }\n    :host > .In{\n      position: absolute;\n      top:56px;\n      right:0px;\n      bottom:40px;\n      left:0px;\n      border: 1px solid transparent;\n      border-width: 6px 5px 5px;\n    }\n    :host > .In > .Bg{\n      position: absolute;\n      top: 0;\n      right: 0;\n      bottom: 0;\n      left: 0;\n      background: #fff;\n      box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.3);\n      border-radius: 4px;\n      font-size: 0;\n      overflow: hidden;\n    }\n\n    :host > .In > .In{\n      position: relative;\n      width: 100%;\n      height: 100%;\n    }\n    :host > .In > .In > .In{\n      position: absolute;\n      left: 20px;\n      right: 20px;\n      top: 25px;\n      bottom: 20px;\n      overflow: auto;\n    }\n    :host > .In > .In > .In::-webkit-scrollbar{\n      width: 6px;\n    }\n    :host > .In > .In > .In::-webkit-scrollbar-track{\n      border-radius: 3px;\n      background: rgba(255,255,255,0);\n    }\n    :host > .In > .In > .In::-webkit-scrollbar-thumb{\n      border-radius: 3px;\n      background: #aaa;\n    }\n\n    .Text{\n      color: #28344f;\n      font-size: 14px;\n      line-height: 1.375;\n    }\n    .Title{\n      font-size: 18px;\n      font-weight: 600;\n      padding-bottom: 15px;\n    }\n    .Text p + p{\n      padding-top: 1em;\n    }\n\n    .Close{\n      background: url( '/images/popup_close_grey.svg' ) 0 0 no-repeat;\n      background-size: 100% 100%;\n      width: 12px;\n      overflow:hidden;font-size:0;text-indent:-9999px;height:0;\n      padding-top:12px;\n      position: absolute;\n      right: 11px;\n      top: 11px;\n      border: 5px solid transparent;\n      cursor: pointer;\n    }\n    .Close:hover{\n      background-image: url( '/images/popup_close_black.svg' );\n    }\n    .Close::after{\n      content: '';\n      display: block;\n      width: 1px;\n      height: 1px;\n      overflow: hidden;\n      position: absolute;\n      top: 0;\n      left: 0;\n      background: url( '/images/popup_close_black.svg' ) 0 -5000px no-repeat;\n    }\n    </style>\n\n    <div class=\"Overlay\" @click=\"", "\">&nbsp;</div>\n    <div class=\"In\">\n      <div class=\"Bg\"></div>\n      <div class=\"In\">\n        <div class=\"In Text\">\n          <p>", "</p>\n          <p>", "</p>\n          <p>", "</p>\n        </div>\n        <div class=\"Close\" @click=\"", "\">X</div>\n      </div>\n    </div>\n    "]);

    _templateObject_3fb9d6d018f511eb992faba69ef4ab6d = function _templateObject_3fb9d6d018f511eb992faba69ef4ab6d() {
      return data;
    };

    return data;
  }

  function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = babelHelpers.getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = babelHelpers.getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return babelHelpers.possibleConstructorReturn(this, result); }; }

  function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

  var translations
  /*: { [ string ]: string }*/
  = (0, _head.$createTranslationObjectDefault)({
    'text1': 'locations_help_1',
    'text2': 'locations_help_2',
    'text3': 'locations_help_3'
  });

  var PopupLocationsInformation = /*#__PURE__*/function (_LitElement) {
    babelHelpers.inherits(PopupLocationsInformation, _LitElement);

    var _super = _createSuper(PopupLocationsInformation);

    function PopupLocationsInformation() {
      babelHelpers.classCallCheck(this, PopupLocationsInformation);
      return _super.apply(this, arguments);
    }

    babelHelpers.createClass(PopupLocationsInformation, [{
      key: "render",
      value: function render() {
        return (0, _head.html)(_templateObject_3fb9d6d018f511eb992faba69ef4ab6d(), _head.$globalStyleDefault, this.close, translations.text1, translations.text2, translations.text3, this.close);
      } // Methods

      /** @method */

    }, {
      key: "close",
      value: function () {
        var _close = babelHelpers.asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
          var _this = this;

          var ffVersion, duration, start, end, animation;
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  _context.next = 2;
                  return _head.$firefoxVersionDefault;

                case 2:
                  ffVersion = _context.sent;
                  duration = 400;

                  if (!(typeof ffVersion === 'number' && ffVersion <= 62)) {
                    _context.next = 11;
                    break;
                  }

                  start = 1;
                  end = 0;
                  _context.next = 9;
                  return (0, _head.$animateDefault)({
                    duration: duration,
                    'action': function action(percent) {
                      var value
                      /*: number */
                      = percent * (end - start) + start;
                      _this.style.cssText = "opacity:".concat(value, ";");
                    }
                  });

                case 9:
                  _context.next = 14;
                  break;

                case 11:
                  animation = this.animate([{
                    'opacity': 1
                  }, {
                    'opacity': 0
                  }], {
                    'duration': 400,
                    'easing': 'linear'
                  });
                  _context.next = 14;
                  return new Promise(function (resolve) {
                    animation.onfinish = resolve;
                  });

                case 14:
                  this.remove();

                case 15:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function close() {
          return _close.apply(this, arguments);
        }

        return close;
      }()
    }]);
    return PopupLocationsInformation;
  }(_head.LitElement);

  ;
  customElements.define('popup-locations-information', PopupLocationsInformation);
});